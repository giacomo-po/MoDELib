/* This file is part of MODEL, the Mechanics Of Defect Evolution Library.
 *
 * Copyright (C) 2011 by Giacomo Po <gpo@ucla.edu>.
 *
 * mmdl is distributed without any warranty under the 
 * GNU General Public License (GPL) v2 <http://www.gnu.org/licenses/>.
 */

#ifndef model_ADDRESSBOOK_H_
#define model_ADDRESSBOOK_H_

#include <map>
#include <iterator>		// for std::distance
#include <model/Utilities/CRTP.h>
#include <model/Utilities/StaticID.h>

namespace model {
	
	//////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////
	template <typename Derived>
	class AddressBookBase{
		
		typedef std::map<size_t,Derived* const> AddressMapType;
		typedef typename AddressMapType::iterator AddressMapIteratorType;
		
	protected:
		static AddressMapType AddressMap;
		
	public:
		//////////////////////////////////////////////////////////////
		// show
		void show() const {
			//! Shows AddressMap.
			for (AddressMapIteratorType map_iter=this->AddressSet.begin(); map_iter!=this->AddressSet.end(); ++map_iter){
				std::cout<<map_iter->first<<map_iter->second<<std::endl;}
		}
		
	};
	
	/////////////////////////////
	// Declare static data member
	template <typename Derived>
	std::map<size_t,Derived* const> AddressBookBase<Derived>::AddressMap;
	
	
	
	
	//////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////
	/*!  
	 *
	 * \brief AddressBook is a class template that stores a static map of pointers to
	 * Derived class objects using the CRTP pattern. The key in the map is the staticID.
	 * The derived object gains access to the pointers of all the other objects of derived type that are instatiated. 
	 * The static map is automatically and dynamically updated during construction/destruction of derived objects. 
	 * A dynamic ID into the static vector is also provided. The typical implementation is:
	 *
	 * \code
	 class Derived : public AddressBook<Derived>{
	 ...
	 };
	 *
	 * \endcode
	 *
	 * For multiple inheritance it's usefulto use the following pattern:
	 *
	 * \code
	 template <typename Derived2>
	 class Derived1 : public AddressBook<Derived2>{
	 ...
	 };
	 *
	 class Derived2 : public Derived1<Derived2>{
	 ...
	 };
	 *
	 * \endcode
	 */
	
	template <typename Derived, bool active = 1>
	class AddressBook{};
	
	
	
	//////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////
	// Template Specialization AddressBook<Derived,1> (active)
	template <typename Derived>
	class AddressBook<Derived,1> :	private AddressBookBase<Derived>,
	/*							*/  public  StaticID<Derived>,
	/*							*/  public  CRTP<Derived>{
		
		typedef std::map<size_t,Derived* const> AddressMapType;
		typedef typename AddressMapType::iterator AddressMapIteratorType;
		

		
		
		public:
				
		AddressMapIteratorType ABbegin() const {
			return this->AddressMap.begin();
		}

		
		AddressMapIteratorType ABend() const {
			return this->AddressMap.end();
		}
		
		
		//////////////////////////////////////////////////////////////
		// Constructor
		AddressBook(){
			//! 1- Insert the pointer to the derived class in AddressMap
			this->AddressMap.insert(std::make_pair( this->sID, this->p_derived() ) );
			//newInstance();
		}
		
		//////////////////////////////////////////////////////////////
		// Copy Constructor
		AddressBook(const AddressBook<Derived> & I){
			//! 1- Insert the pointer to the derived class in AddressMap
			this->AddressMap.insert(std::make_pair( this->sID, this->p_derived() ) );
			//newInstance();
		}
				
		
		//////////////////////////////////////////////////////////////
		// Destructor
		~AddressBook(){
			this->AddressMap.erase( this->sID );
		}
		
		//////////////////////////////////////////////////////////////
		// dID
		size_t dID() const {
			//! Returns the dynamic identifier of the derived object.
			return std::distance(this->AddressMap.begin(),this->AddressMap.find( this->sID ) );
		}
		
		//////////////////////////////////////////////////////////////
		// Naddresses
		size_t  Naddresses() const {
			//! Returns the number of pointers stored in AddressSet
			return this->AddressMap.size();
		}	
		
		//////////////////////////////////////////////////////////////
		// address
		Derived* address(const size_t& k) const {
			// element type of std::map are of type pair<const Key,T>
			// return type of find is an iterator iter to a pair<const Key,T>
			// Dereferencing this iterator accesses the element's value, which is of type pair<const Key,T>
			return this->AddressMap.find(k)->second;
		}
		
	};
	
	
	//////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////
	// Template Specialization AddressBook<Derived,0> (pasive)
	template <typename T>
	class AddressBook<T,0> : private AddressBookBase<T>{
		
		typedef std::map<size_t,T* const> AddressMapType;
		typedef typename AddressMapType::iterator AddressMapIteratorType;
				
	public:
		//////////////////////////////////////////////////////////////
		// Naddresses
		size_t  Naddresses() const {
			//! Returns the number of pointers stored in AddressSet
			return this->AddressMap.size();
		}	
		
		//////////////////////////////////////////////////////////////
		// address
		T* address(const size_t& k) const {
			// element type of std::map are of type pair<const Key,T>
			// return type of find is an iterator iter to a pair<const Key,T>
			// Dereferencing this iterator accesses the element's value, which is of type pair<const Key,T>
			return this->AddressMap.find(k)->second;
		}
		
		AddressMapIteratorType ABbegin() const {
			return this->AddressMap.begin();
		}
		
		
		AddressMapIteratorType ABend() const {
			return this->AddressMap.end();
		}
		
	};
	
} // namespace model
#endif

