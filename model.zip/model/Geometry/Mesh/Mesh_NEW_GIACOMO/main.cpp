#include <iostream>

#include<vector>

//#include <mmdl/Mesh/>
//#include "mmdl/Mesh/Mesh_NEW_GIACOMO/ObservingSet.h"
//#include "mmdl/Mesh/Mesh_NEW_GIACOMO/Simplex.h"








//class MyClass : public mmdl::ObservedBySet<MyClass>{};

int main(){
	

	
	//Eigen::Matrix<unsigned int,1,1> M(3);
	
	
	return 0;
}




